#!/usr/bin/env node
/**
 * generate-from-templates.mjs
 * ===========================
 * Reads leads from a CSV, picks the best-fit template from
 * templates/smoke-shop-sites/sites/, personalises it, and writes
 * a self-contained demo page to public/demos/<slug>/index.html.
 *
 * Usage:
 *   node src/node/generate-from-templates.mjs
 *   node src/node/generate-from-templates.mjs --input data/leads.csv
 *   node src/node/generate-from-templates.mjs --input data/leads.csv --output public/demos
 *   node src/node/generate-from-templates.mjs --template cloud-nine --input data/leads.csv
 *   node src/node/generate-from-templates.mjs --limit 20   # only process first N leads
 */

'use strict';

import fs from 'fs';
import path from 'path';
import csvParser from 'csv-parser';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

const TEMPLATES_DIR  = path.resolve(__dirname, '../../templates/smoke-shop-sites/sites');
const DEFAULT_OUTPUT = path.resolve(__dirname, '../../public/demos');
const DEFAULT_INPUT  = path.resolve(__dirname, '../../data/leads.csv');

// ── Brand colour palettes — rotated per lead so every demo looks distinct ──
const PALETTES = [
    { primary: '#7c3aed', hover: '#6d28d9', accent: '#a78bfa', name: 'purple'  },
    { primary: '#0ea5e9', hover: '#0284c7', accent: '#38bdf8', name: 'blue'    },
    { primary: '#16a34a', hover: '#15803d', accent: '#4ade80', name: 'green'   },
    { primary: '#dc2626', hover: '#b91c1c', accent: '#f87171', name: 'red'     },
    { primary: '#d97706', hover: '#b45309', accent: '#fbbf24', name: 'amber'   },
    { primary: '#0f766e', hover: '#0d6466', accent: '#2dd4bf', name: 'teal'    },
    { primary: '#be185d', hover: '#9d174d', accent: '#f472b6', name: 'pink'    },
    { primary: '#4338ca', hover: '#3730a3', accent: '#818cf8', name: 'indigo'  },
];

// ── Products shown depend on keywords found in the business name ─────────
const PRODUCT_KEYWORDS = {
    vape: ['Vapes & E-Cigarettes', 'Disposables', 'Vape Juice', 'Pods & Coils'],
    hookah: ['Hookah & Shisha', 'Hookah Coals', 'Hookahs', 'Shisha Flavors'],
    cbd: ['CBD Products', 'Delta-8 THC', 'CBD Gummies', 'CBD Tinctures'],
    kratom: ['Kratom', 'Kratom Powder', 'Kratom Capsules', 'OPMS'],
    cigar: ['Premium Cigars', 'Cigarillos', 'Blunts & Wraps', 'Cigar Accessories'],
    smoke: ['Glass Pipes', 'Water Pipes', 'Rolling Papers', 'Lighters'],
    dispensary: ['THC-A Flower', 'Delta-9 Gummies', 'Live Resin', 'Pre-Rolls'],
};

const DEFAULT_PRODUCTS = [
    'Vapes & Disposables', 'CBD Products', 'Delta-8 THC',
    'Kratom', 'Hookah Supplies', 'Glass Pipes', 'Premium Cigars', 'Rolling Papers',
];

function getProducts(businessName = '') {
    const lower = businessName.toLowerCase();
    const found = new Set();
    for (const [kw, prods] of Object.entries(PRODUCT_KEYWORDS)) {
        if (lower.includes(kw)) prods.forEach(p => found.add(p));
    }
    if (found.size === 0) DEFAULT_PRODUCTS.forEach(p => found.add(p));
    return [...found].slice(0, 8);
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function slugify(text) {
    return String(text).toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\w-]+/g, '')
        .replace(/--+/g, '-')
        .replace(/^-+|-+$/g, '');
}

function stateFromCity(cityStr = '') {
    // e.g. "Houston, TX" → "TX"
    const match = cityStr.match(/,\s*([A-Z]{2})$/);
    return match ? match[1] : 'TX';
}

function cityOnly(cityStr = '') {
    return cityStr.split(',')[0].trim();
}

function formatPhone(raw = '') {
    const digits = raw.replace(/\D/g, '');
    if (digits.length === 10) return `(${digits.slice(0,3)}) ${digits.slice(3,6)}-${digits.slice(6)}`;
    if (digits.length === 11 && digits[0] === '1') {
        const d = digits.slice(1);
        return `(${d.slice(0,3)}) ${d.slice(3,6)}-${d.slice(6)}`;
    }
    return raw;
}

function telDigits(raw = '') {
    return raw.replace(/\D/g, '');
}

function getAvailableTemplates() {
    if (!fs.existsSync(TEMPLATES_DIR)) {
        console.error(`❌ Templates directory not found: ${TEMPLATES_DIR}`);
        console.error('   Run: git submodule update --init --recursive');
        process.exit(1);
    }
    return fs.readdirSync(TEMPLATES_DIR).filter(f => f.endsWith('.html'));
}

async function loadLeads(inputPath) {
    return new Promise((resolve, reject) => {
        const leads = [];
        fs.createReadStream(inputPath)
            .pipe(csvParser())
            .on('data', row => leads.push(row))
            .on('end', () => resolve(leads))
            .on('error', reject);
    });
}

// ── Core personalisation ─────────────────────────────────────────────────────

function personalizeTemplate(html, lead, paletteIndex) {
    const palette = PALETTES[paletteIndex % PALETTES.length];

    const name    = lead.business_name || lead.name || 'Your Smoke Shop';
    const city    = cityOnly(lead.city || '');
    const state   = stateFromCity(lead.city || '');
    const phone   = formatPhone(lead.phone || '');
    const tel     = telDigits(lead.phone || '');
    const address = lead.address || `${city}, ${state}`;
    const rating  = parseFloat(lead.rating) || 4.8;
    const reviews = parseInt(lead.review_count || lead.reviews) || 0;
    const mapsUrl = lead.maps_url || `https://maps.google.com/?q=${encodeURIComponent(name + ' ' + city + ' ' + state)}`;
    const products = getProducts(name);

    // Generate a short tagline from the city
    const tagline = `${city}'s Favorite Smoke Shop`;

    let out = html
        // — Business name replacements (order matters: most specific first)
        .replace(/Cloud Nine Smoke Shop/g, name)
        .replace(/Cloud Nine/g, name.split(' ').slice(0, 2).join(' '))
        .replace(/\{\{BUSINESS_NAME\}\}/g, name)
        .replace(/\{\{TAGLINE\}\}/g, tagline)

        // — Location
        .replace(/Denver, CO 80203/g, address)
        .replace(/Denver, CO/g, `${city}, ${state}`)
        .replace(/Denver/g, city)
        .replace(/80203/g, '')
        .replace(/CO\b/g, state)
        .replace(/\{\{CITY\}\}/g, city)
        .replace(/\{\{STATE\}\}/g, state)
        .replace(/\{\{ADDRESS\}\}/g, address)

        // — Phone
        .replace(/\(303\) 555-0199/g, phone || '(555) 000-0000')
        .replace(/tel:3035550199/g, `tel:${tel}`)
        .replace(/\{\{PHONE\}\}/g, phone || '(555) 000-0000')
        .replace(/\{\{PHONE_TEL\}\}/g, tel)

        // — Maps
        .replace(/https:\/\/maps\.google\.com\/\?q=123\+High\+St\+Denver\+CO/g, mapsUrl)
        .replace(/\{\{MAPS_URL\}\}/g, mapsUrl)

        // — Rating
        .replace(/\{\{RATING\}\}/g, String(rating.toFixed(1)))
        .replace(/\{\{REVIEWS\}\}/g, reviews > 0 ? `${reviews} reviews` : 'Great reviews')

        // — Products list (simple CSV injection)
        .replace(/\{\{PRODUCTS_LIST\}\}/g, products.join(', '))

        // — Demo banner / CTA
        .replace(/\{\{DEMO_CTA\}\}/g, `Want this for your shop? <a href="#contact">Let's talk</a>`)
        .replace(/\{\{DEMO_LABEL\}\}/g, '🔥 Free Demo — Contact Us to Go Live');

    // ── Colour swaps ─────────────────────────────────────────────────────────
    // Purple palette (template default) → chosen palette
    out = out
        .replace(/#7c3aed/g, palette.primary)
        .replace(/#6d28d9/g, palette.hover)
        .replace(/#a78bfa/g, palette.accent)
        .replace(/rgba\(124,\s*58,\s*237,\s*0\.15\)/g, palette.primary + '26')
        .replace(/rgba\(124,\s*58,\s*237,\s*0\.3\)/g,  palette.primary + '4d')
        // Gold palette
        .replace(/#c5a059/g, palette.primary)
        .replace(/#d4b472/g, palette.accent)
        .replace(/rgba\(197,160,89,0\.15\)/g, palette.primary + '26')
        .replace(/rgba\(197,160,89,0\.3\)/g,  palette.primary + '4d');

    // ── Inject demo banner at top of <body> ──────────────────────────────────
    const demoBanner = `
<!-- Demo banner — remove when going live -->
<div style="position:fixed;bottom:0;left:0;right:0;z-index:9999;
     background:linear-gradient(90deg,${palette.primary},${palette.accent});
     color:#fff;text-align:center;padding:10px 16px;font-family:sans-serif;
     font-size:13px;font-weight:600;letter-spacing:.02em;box-shadow:0 -2px 12px rgba(0,0,0,.25);">
  🔥 FREE DEMO for ${name} — <a href="#contact" style="color:#fff;text-decoration:underline;">
  Click here to get your real site live today</a>
</div>`;

    if (out.includes('</body>')) {
        out = out.replace('</body>', demoBanner + '\n</body>');
    }

    return out;
}

// ── Main ─────────────────────────────────────────────────────────────────────

async function main() {
    const args = process.argv.slice(2);
    const getFlag = (flag, def = null) => {
        const i = args.indexOf(flag);
        return i !== -1 ? args[i + 1] : def;
    };

    const inputPath      = getFlag('--input', DEFAULT_INPUT);
    const outputDir      = getFlag('--output', DEFAULT_OUTPUT);
    const templateFilter = getFlag('--template');
    const limit          = getFlag('--limit') ? parseInt(getFlag('--limit')) : Infinity;
    const dryRun         = args.includes('--dry-run');

    // ── Choose template ──────────────────────────────────────────────────────
    const templates = getAvailableTemplates();
    console.log(`📄 Available templates: ${templates.join(', ')}`);

    let templateFile = templates[0];
    if (templateFilter) {
        const match = templates.find(t => t.toLowerCase().includes(templateFilter.toLowerCase()));
        if (match) { templateFile = match; }
        else { console.warn(`⚠️  Template "${templateFilter}" not found — using ${templateFile}`); }
    }

    const templateHtml = fs.readFileSync(path.join(TEMPLATES_DIR, templateFile), 'utf8');
    console.log(`✅ Using template: ${templateFile}`);

    // ── Load leads ───────────────────────────────────────────────────────────
    if (!fs.existsSync(inputPath)) {
        console.error(`❌ Input not found: ${inputPath}`);
        console.error('   Run the scraper first: npm run scrape -- --city "Houston"');
        process.exit(1);
    }

    let leads = await loadLeads(inputPath);
    if (leads.length === 0) {
        console.error('❌ No leads found in CSV.');
        process.exit(1);
    }

    if (isFinite(limit)) leads = leads.slice(0, limit);
    console.log(`📋 Processing ${leads.length} leads from ${inputPath}`);

    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

    // ── Generate ─────────────────────────────────────────────────────────────
    let generated = 0, skipped = 0, errors = 0;

    for (let i = 0; i < leads.length; i++) {
        const lead = leads[i];
        const name = lead.business_name || lead.name || '';

        if (!name) { skipped++; continue; }

        const slug    = slugify(name);
        const outDir  = path.join(outputDir, slug);
        const outFile = path.join(outDir, 'index.html');

        if (dryRun) {
            console.log(`[DRY RUN] Would generate: ${outFile}`);
            generated++;
            continue;
        }

        try {
            fs.mkdirSync(outDir, { recursive: true });
            const html = personalizeTemplate(templateHtml, lead, i);
            fs.writeFileSync(outFile, html, 'utf8');
            generated++;

            // Progress every 10 leads
            if (generated % 10 === 0 || generated === leads.length) {
                process.stdout.write(`\r  ✍️  Generated ${generated}/${leads.length} demos…`);
            }
        } catch (err) {
            console.error(`\n❌ Error for "${name}": ${err.message}`);
            errors++;
        }
    }

    console.log(`\n\n✅ Done! Generated: ${generated} | Skipped: ${skipped} | Errors: ${errors}`);
    console.log(`📁 Output: ${outputDir}`);
}

main().catch(err => {
    console.error('Fatal error:', err);
    process.exit(1);
});
