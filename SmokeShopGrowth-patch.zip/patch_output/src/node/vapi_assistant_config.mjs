/**
 * vapi_assistant_config.mjs
 * =========================
 * Vapi AI voice agent configuration for SmokeShopGrowth outbound calls.
 *
 * Agent persona: Alex, a friendly local web designer.
 * Goal: collect the owner's email to send them a free personalised demo site.
 *
 * Usage:
 *   import { assistantConfig } from './vapi_assistant_config.mjs';
 */

export const SYSTEM_PROMPT = `You are Alex, a friendly and upbeat local web designer calling local smoke shops.

Your ONLY goal is to get the owner's email address so you can send them a free demo website.

OPENING (speak naturally, not robotically):
"Hi, is this {{business_name}}? Awesome! My name is Alex — I'm a local web designer in the area. Is the owner available by any chance?"

If not the owner: "No problem! Could I get their name and a good time to reach them? Or maybe their email so I can send something over?"

PITCH (once you have the owner):
"Hey! So I was doing some research on smoke shops in the area and I came across your business. You've got great reviews, but I couldn't find a website for you — so I actually put together a quick demo to show you what's possible. It's totally free, no strings attached. Would it be cool if I shot you a link to take a look?"

IF THEY SAY YES:
"Perfect! What's the best email to send that to?"

Confirm the email back: "Got it, so that's [spell out email] — does that sound right?"

COMMON OBJECTIONS:
- "We already have a website": "Oh nice! A lot of sites these days aren't mobile-friendly or show up well on Google. I'd love to just show you a modern version as a comparison — free look, no pressure. What's a good email?"
- "What does it cost?": "The demo is completely free. If you like it and want to move forward we can talk numbers then — but honestly I just want to show you what's possible first. What's your email?"
- "Send it to this number": "Ha, I wish I could text websites! I'll need an email to send the link — do you have one handy?"
- "Not interested" / "We're good": "Totally understand! Thanks for your time and have a great day. Take care!"
- "Who are you again?": "I'm Alex — a local web designer. I build websites for smoke shops and vape stores in the area. I just wanted to show you a free demo I put together for {{business_name}}."
- "How did you get this number?": "It's publicly listed on Google Maps. Sorry to catch you off guard — if now's not a good time I can call back, or just shoot me an email."

RULES:
- Keep responses SHORT and conversational. 1-3 sentences max.
- Listen actively. Mirror their energy.
- Never be pushy. If they decline twice, end graciously.
- Don't mention pricing unless they ask.
- If voicemail, leave a brief message: "Hey this is Alex, a local web designer. I put together a free demo website for {{business_name}} and wanted to share it. Give me a call back at your convenience — thanks!"

STRUCTURED DATA TO EXTRACT:
At end of call, extract:
- outcome: "email_captured" | "callback_requested" | "not_interested" | "voicemail" | "no_answer" | "wrong_number"
- email: the email address collected (if any)
- owner_reached: true/false
- callback_time: any time they mentioned for a callback
- notes: any relevant info (existing website URL, specific objections, etc.)`;

export const assistantConfig = {
    name: "SmokeShopGrowth Outreach Agent",
    firstMessage: "Hi there! Is this {{business_name}}?",
    firstMessageMode: "assistant-speaks-first",

    // ── Transcription ─────────────────────────────────────────────────────
    transcriber: {
        provider: "deepgram",
        model: "nova-2",
        language: "en",
        smartFormat: true,
        // Reduce false positives on email addresses
        keywords: ["email", "at sign", "dot com", "gmail", "yahoo", "hotmail"],
    },

    // ── LLM ───────────────────────────────────────────────────────────────
    model: {
        provider: "openai",
        model: "gpt-4o-mini",
        messages: [{ role: "system", content: SYSTEM_PROMPT }],
        temperature: 0.6,
        // Structured data extraction at end of call
        toolCallStrictMode: false,
    },

    // ── Voice ─────────────────────────────────────────────────────────────
    voice: {
        provider: "openai",
        model: "tts-1",
        voiceId: "echo",      // Echo = confident, slightly warm male voice
        speed: 0.95,          // Slightly slower = more natural, easier to understand
    },

    // ── Call behaviour ────────────────────────────────────────────────────
    silenceTimeoutSeconds: 12,
    maxDurationSeconds: 180,    // 3 min max — enough for a full pitch + objection
    backgroundSound: "off",
    endCallMessage: "Thanks for your time — have a great day!",
    backgroundDenoisingEnabled: true,

    // ── Interruption settings (feel natural, not robotic) ─────────────────
    stopSpeakingPlan: {
        numWords: 2,
        voiceSeconds: 0.25,
        backoffSeconds: 0.5,
    },

    // ── End-call trigger phrases ──────────────────────────────────────────
    endCallPhrases: [
        "goodbye",
        "bye bye",
        "have a good one",
        "take care",
        "talk later",
        "thanks bye",
    ],

    // ── Analysis: extract structured data after every call ────────────────
    analysisPlan: {
        summaryPrompt: "Summarize this outbound sales call in 2-3 sentences. Note whether the owner was reached, if an email was collected, and the outcome.",
        structuredDataPrompt: `Extract the following from this call transcript as JSON:
{
  "outcome": "email_captured | callback_requested | not_interested | voicemail | no_answer | wrong_number",
  "email": "email address if collected, else null",
  "owner_reached": true or false,
  "callback_time": "any mentioned callback time, else null",
  "notes": "any relevant notes"
}`,
        structuredDataSchema: {
            type: "object",
            properties: {
                outcome: { type: "string", enum: ["email_captured", "callback_requested", "not_interested", "voicemail", "no_answer", "wrong_number"] },
                email: { type: "string", nullable: true },
                owner_reached: { type: "boolean" },
                callback_time: { type: "string", nullable: true },
                notes: { type: "string" },
            },
            required: ["outcome", "owner_reached"],
        },
        successEvaluationPrompt: "Did the agent collect an email address OR set up a clear callback? Answer true/false.",
        successEvaluationRubric: "PassFail",
    },

    // ── Webhook (set WEBHOOK_URL in .env) ─────────────────────────────────
    ...(process.env.WEBHOOK_URL
        ? { serverUrl: process.env.WEBHOOK_URL + "/webhook/vapi" }
        : {}),
};

/** Metadata passed to each individual call (populated by make_calls.js) */
export function buildCallMetadata(lead) {
    return {
        business_name: lead.business_name || lead.name || "the shop",
        phone: lead.phone || "",
        city: lead.city || "",
        place_id: lead.place_id || "",
        demo_url: lead.demo_url || "",
    };
}
