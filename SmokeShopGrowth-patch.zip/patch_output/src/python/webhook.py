"""
SmokeShopGrowth — Unified Webhook Server (Flask)
=================================================
Handles: Stripe payments, Vapi call callbacks, pipeline job triggers,
         form submissions, and demo email delivery.

Run:  python src/python/webhook.py
      PORT=4242 python src/python/webhook.py
"""

import os
import sys
import subprocess
import threading
import uuid
import smtplib
from datetime import datetime
from email.message import EmailMessage
from urllib.parse import quote

# ── Path fix: make src/agents/ and src/python/ importable ──────────────────
_here = os.path.dirname(os.path.abspath(__file__))
_agents_dir = os.path.abspath(os.path.join(_here, "..", "agents"))
_python_dir = _here
for _p in (_agents_dir, _python_dir):
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)

# ── Dependency imports (fail fast with a clear message) ────────────────────
try:
    import stripe
    from flask import Flask, jsonify, request
    from dotenv import load_dotenv
except ImportError as exc:
    print(f"[FATAL] Missing dependency: {exc}")
    print("Run:  pip install flask stripe python-dotenv")
    sys.exit(1)

# ── Local imports ───────────────────────────────────────────────────────────
from config import (
    DEMO_BASE_URL,
    SENDER_NAME,
    SMTP_HOST,
    SMTP_PASS,
    SMTP_PORT,
    SMTP_USER,
    STRIPE_API_KEY,
    STRIPE_WEBHOOK_SECRET,
)

try:
    from crm import lookup_lead_from_crm, update_crm_deployed, update_crm_payment
    from delivery_agent import trigger_delivery_flow
    from deploy_agent import deploy_shop_website
    from error_handler import log_failed_job
    from logger import get_logger
    _CRM_AVAILABLE = True
except ImportError:
    _CRM_AVAILABLE = False
    import logging
    def get_logger(name):
        return logging.getLogger(name)

load_dotenv()
log = get_logger(__name__)

# ── Flask app ────────────────────────────────────────────────────────────────
app = Flask(__name__)

stripe.api_key = STRIPE_API_KEY
endpoint_secret = STRIPE_WEBHOOK_SECRET

# ── In-memory stores ─────────────────────────────────────────────────────────
pipeline_jobs = {}      # job_id → {status, city, bizType, …}
template_submissions = []

# ============================================================================
# HELPERS
# ============================================================================

def send_demo_email(to_email, business_name, city):
    """Send follow-up email containing the personalised demo link."""
    if not SMTP_USER or not SMTP_PASS:
        log.warning("SMTP credentials missing — cannot send email.")
        return False

    demo_url = f"{DEMO_BASE_URL}/?shop={quote(business_name)}&city={quote(city)}"

    msg = EmailMessage()
    msg["Subject"] = f"Your free demo site — {business_name}"
    msg["From"] = f"{SENDER_NAME} <{SMTP_USER}>"
    msg["To"] = to_email

    html = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8" /></head>
<body style="margin:0;padding:0;background:#0a0a0a;font-family:sans-serif;color:#fff;">
  <div style="max-width:580px;margin:0 auto;padding:40px 24px;">
    <h1 style="color:#00f0ff;font-size:1.6rem;margin-bottom:8px;">Hey {business_name} 👋</h1>
    <p style="color:#ccc;font-size:1rem;line-height:1.7;margin-bottom:24px;">
      I'm <strong>{SENDER_NAME}</strong>, the local web developer. Here's the free demo
      site I built for your smoke shop in <strong>{city}</strong>:
    </p>
    <div style="text-align:center;margin:32px 0;">
      <a href="{demo_url}"
         style="display:inline-block;background:linear-gradient(90deg,#00f0ff,#39ff14);
                color:#000;font-weight:700;padding:14px 36px;border-radius:999px;
                font-size:1.1rem;text-decoration:none;">
        👁 View Your Free Demo
      </a>
    </div>
    <p style="color:#aaa;font-size:.9rem;line-height:1.7;">
      No commitment — just a free look. Reply here or call me if you want to move forward.
    </p>
    <hr style="border:none;border-top:1px solid #222;margin:32px 0;" />
    <p style="color:#666;font-size:.82rem;">
      {SENDER_NAME} • Local Web Developer<br />
      This demo was created specifically for {business_name}
    </p>
  </div>
</body></html>"""

    msg.set_content(f"Hey {business_name},\n\nHere's your free demo site: {demo_url}\n\n— {SENDER_NAME}")
    msg.add_alternative(html, subtype="html")

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.send_message(msg)
        log.info(f"Demo email sent to {to_email}")
        return True
    except Exception as exc:
        log.error(f"Failed to send demo email: {exc}")
        return False


def create_checkout_session(lead_email, business_name, city, tier="growth"):
    """Create a Stripe Checkout Session and return the URL (or None)."""
    TIER_PRICES = {
        "starter": {"setup": 9900,  "name": "Starter Website"},
        "growth":  {"setup": 29900, "name": "Growth Website"},
        "pro":     {"setup": 49900, "name": "Pro Website"},
    }
    selected = TIER_PRICES.get(tier, TIER_PRICES["growth"])

    try:
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            mode="payment",
            client_reference_id=lead_email,
            customer_email=lead_email,
            metadata={"business_name": business_name, "city": city, "tier": tier},
            line_items=[{
                "price_data": {
                    "currency": "usd",
                    "product_data": {
                        "name": f"{selected['name']} — {business_name}",
                        "description": f"Custom smoke shop website for {business_name} in {city}",
                    },
                    "unit_amount": selected["setup"],
                },
                "quantity": 1,
            }],
            success_url=f"{DEMO_BASE_URL}/?shop={quote(business_name)}&city={quote(city)}&paid=true",
            cancel_url=f"{DEMO_BASE_URL}/?shop={quote(business_name)}&city={quote(city)}",
        )
        log.info(f"Stripe checkout session created: {session.url}")
        return session.url
    except Exception as exc:
        log.error(f"Failed to create Stripe checkout session: {exc}")
        return None


def trigger_site_deployment(email, ref_id, stripe_metadata=None):
    """Look up the CRM lead and deploy their personalised site."""
    log.info(f"[DEPLOY] Triggering site build for {email}…")

    lead_data = None
    if _CRM_AVAILABLE:
        lead_data = lookup_lead_from_crm(email, ref_id)

    if not lead_data and stripe_metadata:
        log.info("[DEPLOY] CRM lookup failed — falling back to Stripe metadata.")
        lead_data = {
            "business_name": stripe_metadata.get("business_name", "Smoke Shop"),
            "city": stripe_metadata.get("city", "Houston"),
            "phone": "",
            "address": "",
            "email": email,
            "maps_url": "https://maps.google.com",
            "custom_domain": None,
        }

    if not lead_data:
        msg = f"No lead data found for email={email}, ref_id={ref_id}"
        log.error(msg)
        if _CRM_AVAILABLE:
            log_failed_job("deploy", {"email": email, "ref_id": ref_id}, msg)
        return

    lead_data["email"] = lead_data.get("email") or email

    try:
        deployed_url = deploy_shop_website(lead_data) if _CRM_AVAILABLE else None

        if deployed_url:
            log.info(f"Site deployed: {deployed_url}")
            if _CRM_AVAILABLE:
                update_crm_deployed(email, deployed_url)
                try:
                    trigger_delivery_flow(lead_data, deployed_url)
                except Exception as exc:
                    log_failed_job("delivery", {"lead_data": lead_data, "live_url": deployed_url}, str(exc))
        else:
            log.error("Deployment returned None — queuing retry.")
            if _CRM_AVAILABLE:
                log_failed_job("deploy", lead_data, "Deployment script returned None")
    except Exception as exc:
        log.critical(f"Fatal error during deployment: {exc}")
        if _CRM_AVAILABLE:
            log_failed_job("deploy", lead_data, str(exc))


# ── Pipeline runner ──────────────────────────────────────────────────────────

def _run_pipeline_async(job_id, city, biz_type, max_results):
    """Background thread: run the scraper pipeline."""
    try:
        pipeline_jobs[job_id]["status"] = "running"

        # Resolve project root (two levels up from src/python/)
        project_root = os.path.abspath(os.path.join(_here, "..", ".."))
        scraper_path = os.path.join(project_root, "src", "python", "scraper.py")

        result = subprocess.run(
            [
                sys.executable, scraper_path,
                "--city", city,
                "--type", biz_type,
                "--max-results", str(max_results),
                "--headless",
            ],
            capture_output=True, text=True, timeout=600,
            cwd=project_root,
        )

        if result.returncode == 0:
            pipeline_jobs[job_id]["status"] = "done"
            pipeline_jobs[job_id]["output"] = result.stdout[-2000:]
        else:
            pipeline_jobs[job_id]["status"] = "failed"
            pipeline_jobs[job_id]["error"] = result.stderr[-1000:]

    except subprocess.TimeoutExpired:
        pipeline_jobs[job_id]["status"] = "failed"
        pipeline_jobs[job_id]["error"] = "Pipeline timed out after 10 minutes"
    except Exception as exc:
        pipeline_jobs[job_id]["status"] = "failed"
        pipeline_jobs[job_id]["error"] = str(exc)
    finally:
        pipeline_jobs[job_id]["finished_at"] = datetime.utcnow().isoformat()


# ============================================================================
# ROUTES
# ============================================================================

@app.route("/health", methods=["GET"])
def health():
    return jsonify(status="ok", timestamp=datetime.utcnow().isoformat()), 200


# ── Stripe checkout creation ─────────────────────────────────────────────────

@app.route("/create-checkout", methods=["POST"])
def create_checkout():
    data = request.get_json(silent=True) or {}
    email = data.get("email", "").strip()
    business_name = data.get("business_name", "").strip()
    city = data.get("city", "").strip()
    tier = data.get("tier", "growth").strip().lower()

    if not email or not business_name:
        return jsonify(error="email and business_name are required"), 400

    if tier not in ("starter", "growth", "pro"):
        tier = "growth"

    url = create_checkout_session(email, business_name, city, tier)
    if url:
        return jsonify(checkout_url=url)
    return jsonify(error="Failed to create checkout session"), 500


# ── Stripe webhook ───────────────────────────────────────────────────────────

@app.route("/webhook", methods=["POST"])
def stripe_webhook():
    payload = request.data
    sig_header = request.headers.get("STRIPE_SIGNATURE") or request.headers.get("Stripe-Signature")

    if not endpoint_secret:
        log.error("STRIPE_WEBHOOK_SECRET not configured")
        return "No webhook secret configured.", 400

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, endpoint_secret)
    except ValueError:
        log.error("Stripe webhook: invalid payload")
        return "Invalid payload", 400
    except stripe.SignatureVerificationError:
        log.error("Stripe webhook: invalid signature")
        return "Invalid signature", 400

    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        customer_email = (
            session.get("customer_details", {}).get("email", "")
            or session.get("customer_email", "")
        )
        amount_paid = session.get("amount_total", 0) / 100.0
        client_reference_id = session.get("client_reference_id")
        stripe_metadata = session.get("metadata", {})

        log.info(f"✅ Payment received — {customer_email} ${amount_paid:.2f}")

        if _CRM_AVAILABLE:
            update_crm_payment(customer_email, client_reference_id)

        trigger_site_deployment(customer_email, client_reference_id, stripe_metadata)

    return jsonify(success=True)


# ── Vapi webhook ─────────────────────────────────────────────────────────────

@app.route("/vapi/webhook", methods=["POST"])
def vapi_webhook():
    data = request.get_json(silent=True) or {}
    event_type = data.get("message", {}).get("type") or data.get("type")

    if event_type in ("end-of-call-report", "end_of_call_report"):
        analysis = data.get("message", {}).get("analysis") or {}
        structured = analysis.get("structuredData") or {}
        call = data.get("message", {}).get("call") or {}
        metadata = call.get("metadata") or {}

        business_name = metadata.get("business_name") or structured.get("business_name", "Shop Owner")
        city = metadata.get("city", "your city")
        email = structured.get("email")

        # Fallback: look for email in contact_value
        contact_value = structured.get("contact_value")
        if not email and contact_value and "@" in contact_value:
            email = contact_value

        log.info(f"Vapi call ended — {business_name} | outcome: {structured.get('outcome')}")

        if email:
            log.info(f"  Email collected: {email} — sending demo…")
            send_demo_email(email, business_name, city)
        else:
            log.info("  No email collected during call.")

    return jsonify(status="received"), 200


# ── Pipeline API (used by dashboard / n8n) ───────────────────────────────────

@app.route("/api/run", methods=["POST"])
def api_run_pipeline():
    data = request.get_json(silent=True) or {}
    city = data.get("city", "").strip()
    biz_type = data.get("bizType", "smoke shop").strip()

    try:
        max_results = min(int(data.get("maxResults", 100)), 500)
    except (TypeError, ValueError):
        max_results = 100

    if not city:
        return jsonify(error="city is required"), 400

    job_id = str(uuid.uuid4())[:8]
    pipeline_jobs[job_id] = {
        "status": "queued",
        "city": city,
        "bizType": biz_type,
        "started_at": datetime.utcnow().isoformat(),
        "finished_at": None,
        "error": None,
        "output": None,
    }

    thread = threading.Thread(
        target=_run_pipeline_async,
        args=(job_id, city, biz_type, max_results),
        daemon=True,
    )
    thread.start()

    log.info(f"[PIPELINE] Started job {job_id}: {city} / {biz_type}")
    return jsonify(status="started", jobId=job_id, message="Pipeline triggered"), 200


@app.route("/api/jobs", methods=["GET"])
def api_list_jobs():
    jobs_list = [
        {
            "id": jid,
            "status": j["status"],
            "city": j["city"],
            "bizType": j["bizType"],
            "started_at": j["started_at"],
            "finished_at": j["finished_at"],
            "error": j.get("error"),
        }
        for jid, j in pipeline_jobs.items()
    ]
    return jsonify(jobs_list), 200


@app.route("/api/jobs/<job_id>", methods=["GET"])
def api_get_job(job_id):
    job = pipeline_jobs.get(job_id)
    if not job:
        return jsonify(error="Job not found"), 404
    return jsonify({"id": job_id, **job}), 200


# ── Template/form submissions ────────────────────────────────────────────────

@app.route("/api/template-submission", methods=["POST"])
def api_template_submission():
    data = request.get_json(silent=True) or {}
    shop_name = data.get("shopName", "").strip()
    city = data.get("city", "").strip()
    phone = data.get("phone", "").strip()
    email = data.get("email", "").strip()

    if not shop_name or not city or not phone or not email:
        return jsonify(error="Missing required fields: shopName, city, phone, email"), 400

    submission = {
        "id": str(uuid.uuid4())[:8],
        "shopName": shop_name,
        "city": city,
        "phone": phone,
        "email": email,
        "source": data.get("source", "form"),
        "timestamp": datetime.utcnow().isoformat(),
    }
    template_submissions.append(submission)
    log.info(f"[FORM] New submission: {shop_name} ({city}) — {email}")
    return jsonify(success=True, message="Submission received", submissionId=submission["id"]), 200


@app.route("/api/template-submissions", methods=["GET"])
def api_list_template_submissions():
    return jsonify(count=len(template_submissions), submissions=template_submissions), 200


# ── 404 handler ──────────────────────────────────────────────────────────────

@app.errorhandler(404)
def not_found(exc):
    return jsonify(error="Not found", path=request.path), 404


@app.errorhandler(500)
def internal_error(exc):
    log.error(f"Internal server error: {exc}")
    return jsonify(error="Internal server error"), 500


# ============================================================================
# ENTRYPOINT
# ============================================================================

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 4242))
    debug = os.environ.get("FLASK_DEBUG", "").lower() == "true"

    log.info(f"Starting SmokeShopGrowth webhook server on port {port}…")

    if not STRIPE_API_KEY:
        log.warning("⚠️  STRIPE_API_KEY not set")
    if not endpoint_secret or endpoint_secret.startswith("whsec_..."):
        log.warning("⚠️  STRIPE_WEBHOOK_SECRET not configured")

    app.run(host="0.0.0.0", port=port, debug=debug)
